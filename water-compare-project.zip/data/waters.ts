export const waters = [
  { id: 1, name: "Aqua Pure", pH: 7.4, hardness: 120, calcium: 40, magnesium: 12, sodium: 30, nitrate: 3 },
  { id: 2, name: "Crystal Spring", pH: 7.0, hardness: 90, calcium: 35, magnesium: 10, sodium: 15, nitrate: 1 },
  { id: 3, name: "Clear Mountain", pH: 7.8, hardness: 105, calcium: 38, magnesium: 11, sodium: 25, nitrate: 2 }
];